<?php
session_start();
include 'db.php';

if(!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$login_name = $_SESSION['admin'];
$get_id = mysqli_query($conn, "SELECT student_id FROM students WHERE name = '$login_name'");
$row_id = mysqli_fetch_assoc($get_id);
$my_id = $row_id['student_id'] ?? 0;

// Total Summary
$total_sql = "SELECT COUNT(*) as total FROM attendance WHERE student_id = '$my_id'";
$total_res = mysqli_fetch_assoc(mysqli_query($conn, $total_sql));
$total_classes = $total_res['total'];

$present_sql = "SELECT COUNT(*) as present FROM attendance WHERE student_id = '$my_id' AND status = 'Present'";
$present_res = mysqli_fetch_assoc(mysqli_query($conn, $present_sql));
$present_classes = $present_res['present'];

$percentage = ($total_classes > 0) ? ($present_classes / $total_classes) * 100 : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>My Attendance</title>
</head>
<body class="container mt-5">
    <div class="d-flex justify-content-between mb-4">
        <h3>Attendance for: <?php echo $login_name; ?> (ID: <?php echo $my_id; ?>)</h3>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>

    <div class="card mb-4 border-primary">
        <div class="card-body">
            <h5>Attendance Summary: <span class="text-primary"><?php echo round($percentage, 2); ?>%</span></h5>
            <p>Total Classes: <?php echo $total_classes; ?> | Present: <?php echo $present_classes; ?></p>
        </div>
    </div>

    <div class="card mb-4 border-info">
        <div class="card-body">
            <h5>Course-wise Attendance:</h5>
            <table class="table table-bordered">
                <thead class="table-info">
                    <tr><th>Course</th><th>Total</th><th>Present</th><th>%</th></tr>
                </thead>
                <tbody>
                <?php
                // Fixed Query: COUNT(*) use kiya hai taake column ka error na aaye
                $cw_sql = "SELECT c.course_name, 
                           COUNT(*) as total_c, 
                           SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_c 
                           FROM attendance a 
                           JOIN courses c ON a.course_id = c.course_id 
                           WHERE a.student_id = '$my_id' 
                           GROUP BY c.course_name";
                
                $cw_res = mysqli_query($conn, $cw_sql);
                
                if(mysqli_num_rows($cw_res) > 0) {
                    while($row = mysqli_fetch_assoc($cw_res)) {
                        $p = ($row['total_c'] > 0) ? ($row['present_c'] / $row['total_c']) * 100 : 0;
                        $p_color = ($p < 70) ? 'text-danger fw-bold' : 'text-success';
                        
                        echo "<tr>
                                <td>{$row['course_name']}</td>
                                <td>{$row['total_c']}</td>
                                <td>{$row['present_c']}</td>
                                <td class='$p_color'>" . round($p, 1) . "%</td>
                              </tr>";
                        
                        if($p < 70) {
                            echo "<tr><td colspan='4' class='text-danger small'>⚠️ Warning: Short attendance in {$row['course_name']}!</td></tr>";
                        }
                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center'>No records found.</td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>