<?php
session_start(); 
if(!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include 'db.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Add Student</title>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow p-4">
                <h3 class="text-center mb-4">Add New Student</h3>
                
                <form method="POST">
                    <div class="mb-3">
                        <label>Student Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter full name" required>
                    </div>
                    <div class="mb-3">
                        <label>Roll Number</label>
                        <input type="text" name="roll_no" class="form-control" placeholder="Enter roll number" required>
                    </div>
                    
                    <button type="submit" name="save" class="btn btn-primary w-100">Save Student</button>
                    <a href="index.php" class="btn btn-secondary w-100 mt-2">Back to Dashboard</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
if(isset($_POST['save'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']); 
    $roll = mysqli_real_escape_string($conn, $_POST['roll_no']);
    
    // Yahan $sql variable define kiya
    $sql = "INSERT INTO students (name, roll_no, password) VALUES ('$name', '$roll', '123')";
    
    // Yahan $sql ko execute kiya, ab error nahi aayega
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Student added successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>
</body>
</html>