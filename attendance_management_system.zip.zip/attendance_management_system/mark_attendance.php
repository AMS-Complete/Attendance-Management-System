<?php
session_start();
// Security Gate: Sirf Admin access kar sakta hai
if(!isset($_SESSION['admin']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
include 'db.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Mark Attendance</title>
</head>
<body class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Mark Attendance</h3>
        <div>
            <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
            <a href="view_attendance.php" class="btn btn-outline-primary">View Full Report</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <form method="POST" class="bg-light p-4 rounded shadow-sm">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Teacher Name</label>
                <input type="text" name="teacher_name" class="form-control" placeholder="e.g. Rabia Faisal" required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Select Course</label>
                <select name="course_id" class="form-select" required>
                    <option value="">-- Select Course --</option>
                    <?php 
                    $res = mysqli_query($conn, "SELECT * FROM courses");
                    while($row = mysqli_fetch_assoc($res)) {
                        echo "<option value='".$row['course_id']."'>".$row['course_name']."</option>";
                    }
                    ?>
                </select>
            </div>
        </div>

        <table class="table table-hover table-bordered mt-3">
            <thead class="table-dark">
                <tr><th>Student Name</th><th>Status</th></tr>
            </thead>
            <tbody>
            <?php
            // SIRF ACTIVE STUDENTS (status = 1)
            $students = mysqli_query($conn, "SELECT * FROM students WHERE status = 1");
            
            if(mysqli_num_rows($students) > 0) {
                while($s = mysqli_fetch_assoc($students)) {
                    echo "<tr>
                            <td>{$s['name']}</td>
                            <td>
                                <div class='form-check form-check-inline'>
                                    <input class='form-check-input' type='radio' name='att[{$s['student_id']}]' value='Present' required>
                                    <label class='form-check-label'>Present</label>
                                </div>
                                <div class='form-check form-check-inline'>
                                    <input class='form-check-input' type='radio' name='att[{$s['student_id']}]' value='Absent'>
                                    <label class='form-check-label'>Absent</label>
                                </div>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='2' class='text-center text-danger'>No Active Students Found.</td></tr>";
            }
            ?>
            </tbody>
        </table>
        <button type="submit" name="submit" class="btn btn-success btn-lg w-100">Save Attendance</button>
    </form>

    <?php
    if(isset($_POST['submit'])){
        $t = mysqli_real_escape_string($conn, $_POST['teacher_name']);
        $c = $_POST['course_id'];
        $date = date('Y-m-d');

        // DUPLICATE ENTRY CHECK
        $check_duplicate = mysqli_query($conn, "SELECT * FROM attendance WHERE date = '$date' AND course_id = '$c' AND teacher_name = '$t'");
        
        if(mysqli_num_rows($check_duplicate) > 0) {
            echo "<script>alert('Attention: Attendance for this Course and Teacher is already marked for today!'); window.location.href='mark_attendance.php';</script>";
        } else {
            foreach($_POST['att'] as $id => $status){
                $sql = "INSERT INTO attendance (student_id, status, date, course_id, teacher_name) 
                        VALUES ('$id', '$status', '$date', '$c', '$t')";
                mysqli_query($conn, $sql);
            }
            echo "<script>alert('Attendance successfully recorded!'); window.location.href='view_attendance.php';</script>";
        }
    }
    ?>
</body>
</html>