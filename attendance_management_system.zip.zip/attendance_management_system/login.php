<?php 
session_start(); 
include 'db.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Login - Attendance System</title>
    <style>
        body { background-color: #f8f9fa; }
        .login-card { border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card login-card p-4">
                <h3 class="text-center mb-4">System Login</h3>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="user" class="form-control" placeholder="Enter Name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="pass" class="form-control" placeholder="Enter Password" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary w-100">Sign In</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
if(isset($_POST['login'])){
    $user = mysqli_real_escape_string($conn, $_POST['user']);
    $pass = mysqli_real_escape_string($conn, $_POST['pass']);
    
    // 1. Pehle Admin table check karo
    $res_admin = mysqli_query($conn, "SELECT * FROM admin WHERE name='$user' AND password='$pass'");
    
    // 2. Agar Admin nahi mila, to Students table check karo
    $res_student = mysqli_query($conn, "SELECT * FROM students WHERE name='$user' AND password='$pass'");
    
    if(mysqli_num_rows($res_admin) > 0){
        $row = mysqli_fetch_assoc($res_admin);
        $_SESSION['admin'] = $row['name'];
        $_SESSION['role'] = $row['role']; 
        header("Location: index.php");
        exit();
    } 
    elseif(mysqli_num_rows($res_student) > 0){
        $row = mysqli_fetch_assoc($res_student);
        $_SESSION['admin'] = $row['name'];
        $_SESSION['role'] = 'student'; 
        header("Location: view_my_attendance.php");
        exit();
    } 
    else {
        echo "<script>alert('Invalid Username or Password!');</script>";
    }
}
?>
</body>
</html>