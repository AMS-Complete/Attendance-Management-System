<?php
session_start();
if(!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
include 'db.php'; 

// Filter logic
$filter_date = $_GET['filter_date'] ?? '';
$filter_course = $_GET['filter_course'] ?? '';

$where_parts = [];
if(!empty($filter_date)) $where_parts[] = "a.date = '$filter_date'";
if(!empty($filter_course)) $where_parts[] = "a.course_id = '$filter_course'";
$where_clause = !empty($where_parts) ? " WHERE " . implode(" AND ", $where_parts) : "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Attendance Report</title>
</head>
<body class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Attendance Report</h3>
        <div>
            <a href="index.php" class="btn btn-dark">Dashboard</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <form method="GET" class="row mb-4 bg-light p-3 rounded">
        <div class="col-md-3">
            <input type="date" name="filter_date" class="form-control" value="<?php echo $filter_date; ?>">
        </div>
        <div class="col-md-3">
            <select name="filter_course" class="form-select">
                <option value="">All Courses</option>
                <?php 
                $res = mysqli_query($conn, "SELECT * FROM courses");
                while($row = mysqli_fetch_assoc($res)) {
                    $selected = ($filter_course == $row['course_id']) ? 'selected' : '';
                    echo "<option value='".$row['course_id']."' $selected>".$row['course_name']."</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Filter</button></div>
        <div class="col-md-2"><a href="view_attendance.php" class="btn btn-secondary w-100">Reset</a></div>
        <div class="col-md-2"><a href="export_attendance.php?date=<?php echo $filter_date; ?>&course=<?php echo $filter_course; ?>" class="btn btn-success w-100">Download Excel</a></div>
    </form>

    <?php
    $sql = "SELECT a.attn_id, a.date, a.teacher_name, c.course_name, s.name, a.status 
            FROM attendance a 
            LEFT JOIN students s ON a.student_id = s.student_id
            LEFT JOIN courses c ON a.course_id = c.course_id 
            $where_clause
            ORDER BY a.date DESC, a.teacher_name, c.course_name";
    
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $current_group = "";
        while($row = mysqli_fetch_assoc($result)) {
            $group_key = $row['date'] . $row['teacher_name'] . $row['course_name'];
            if($group_key != $current_group) {
                if($current_group != "") echo "</tbody></table></div>";
                echo "<div class='card mb-4 shadow-sm border-dark'>
                        <div class='card-header bg-dark text-white'><strong>Date:</strong> {$row['date']} | <strong>Teacher:</strong> {$row['teacher_name']} | <strong>Course:</strong> {$row['course_name']}</div>
                        <table class='table table-bordered mb-0'>
                            <thead class='table-light'><tr><th>Student</th><th>Status</th><th>Action</th></tr></thead>
                            <tbody>";
                $current_group = $group_key;
            }
            $badge = ($row['status'] == 'Present') ? 'bg-success' : 'bg-danger';
            echo "<tr><td>{$row['name']}</td><td><span class='badge $badge'>{$row['status']}</span></td><td><a href='edit_attendance.php?id={$row['attn_id']}' class='btn btn-sm btn-outline-warning'>Edit</a></td></tr>";
        }
        echo "</tbody></table></div>";
    } else {
        echo "<div class='alert alert-warning text-center'>No records found.</div>";
    }
    ?>
</body>
</html>