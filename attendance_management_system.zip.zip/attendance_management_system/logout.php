<?php
session_start();


session_unset(); 
session_destroy(); 

// Wapas login page par bhej dein
header("Location: login.php"); 
exit();
?>