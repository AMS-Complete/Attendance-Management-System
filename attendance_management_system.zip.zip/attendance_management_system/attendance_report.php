<?php
session_start();
// Security Gate: Sirf Admin access kar sakta hai
if(!isset($_SESSION['admin']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
include 'db.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Course-wise Report</title>
</head>
<body class="container mt-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Attendance Percentage (Course-wise)</h3>
        <div>
            <a href="view_attendance.php" class="btn btn-secondary">← Back to Daily Report</a>
            <a href="index.php" class="btn btn-dark">Back to Dashboard</a>
        </div>
    </div>

    <?php
    $courses = mysqli_query($conn, "SELECT * FROM courses");
    
    while($course = mysqli_fetch_assoc($courses)) {
        $c_id = $course['course_id'];
        
        $sql = "SELECT s.name, 
                COUNT(a.student_id) as total, 
                SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) as present 
                FROM attendance a 
                JOIN students s ON a.student_id = s.student_id 
                WHERE a.course_id = '$c_id' 
                GROUP BY a.student_id";
        
        $res = mysqli_query($conn, $sql);
        
        if(mysqli_num_rows($res) > 0) {
            echo "<div class='card mb-4 shadow-sm'>
                    <div class='card-header bg-primary text-white'><h5>Course: {$course['course_name']}</h5></div>
                    <table class='table table-bordered mb-0'>
                        <thead><tr><th>Student Name</th><th>Percentage</th><th>Status</th></tr></thead>
                        <tbody>";
            
            while($row = mysqli_fetch_assoc($res)) {
                $perc = round(($row['present'] / $row['total']) * 100, 2);
                $status = ($perc < 70) ? "<span class='badge bg-danger'>Short Attendance</span>" : "<span class='badge bg-success'>Clear</span>";
                
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$perc}%</td>
                        <td>$status</td>
                      </tr>";
            }
            echo "</tbody></table></div>";
        }
    }
    ?>
</body>
</html>