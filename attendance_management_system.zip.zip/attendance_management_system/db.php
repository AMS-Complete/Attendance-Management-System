<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "attendencemanagmentsystem";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection fail ho gaya: " . mysqli_connect_error());
}
?>