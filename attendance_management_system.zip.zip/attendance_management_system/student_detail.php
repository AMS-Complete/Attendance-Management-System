<?php
session_start();
include 'db.php';

// Student select karne ke baad data layenge
$selected_student = isset($_GET['student_id']) ? $_GET['student_id'] : "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Student Attendance Detail</title>
</head>
<body class="container mt-5">

    <h3>Student Attendance Detail</h3>
    <a href="index.php" class="btn btn-dark mb-4">Back to Dashboard</a>

    <form method="GET" class="row mb-4">
        <div class="col-md-4">
            <select name="student_id" class="form-control" required>
                <option value="">Select Student</option>
                <?php
                $s_query = mysqli_query($conn, "SELECT * FROM students");
                while($s = mysqli_fetch_assoc($s_query)) {
                    $sel = ($selected_student == $s['student_id']) ? "selected" : "";
                    echo "<option value='{$s['student_id']}' $sel>{$s['name']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary">View Details</button>
        </div>
    </form>

    <?php
    if(!empty($selected_student)) {
        // Stats nikalne ki query
        $sql = "SELECT a.date, a.status, c.course_name 
                FROM attendance a 
                JOIN courses c ON a.course_id = c.course_id 
                WHERE a.student_id = '$selected_student' 
                ORDER BY a.date DESC";
        
        $res = mysqli_query($conn, $sql);
        
        // Count totals
        $total_res = mysqli_query($conn, "SELECT COUNT(*) as total, 
                                        SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) as present 
                                        FROM attendance WHERE student_id = '$selected_student'");
        $stats = mysqli_fetch_assoc($total_res);

        echo "<div class='alert alert-secondary'>
                <strong>Total Classes:</strong> {$stats['total']} | 
                <strong>Present:</strong> {$stats['present']} | 
                <strong>Absent:</strong> " . ($stats['total'] - $stats['present']) . "
              </div>";

        echo "<table class='table table-bordered'>
                <thead class='table-dark'><tr><th>Date</th><th>Course</th><th>Status</th></tr></thead>
                <tbody>";
        while($row = mysqli_fetch_assoc($res)) {
            $badge = ($row['status'] == 'Present') ? 'bg-success' : 'bg-danger';
            echo "<tr>
                    <td>{$row['date']}</td>
                    <td>{$row['course_name']}</td>
                    <td><span class='badge $badge'>{$row['status']}</span></td>
                  </tr>";
        }
        echo "</tbody></table>";
    }
    ?>
</body>
</html>