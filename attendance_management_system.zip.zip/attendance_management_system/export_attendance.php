<?php
session_start();
include 'db.php';
if(!isset($_SESSION['admin'])) { exit(); }

$where = [];
$filename = "Attendance_Report.xls";

if(!empty($_GET['date'])) {
    $date = mysqli_real_escape_string($conn, $_GET['date']);
    $where[] = "a.date = '$date'";
}
if(!empty($_GET['course'])) {
    $course = mysqli_real_escape_string($conn, $_GET['course']);
    $where[] = "a.course_id = '$course'";
}

$where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");

echo "Date\tTeacher\tCourse\tStudent\tStatus\n";

$sql = "SELECT a.date, a.teacher_name, c.course_name, s.name, a.status 
        FROM attendance a 
        LEFT JOIN students s ON a.student_id = s.student_id
        LEFT JOIN courses c ON a.course_id = c.course_id 
        $where_sql
        ORDER BY a.date DESC";

$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
    echo $row['date'] . "\t" . $row['teacher_name'] . "\t" . $row['course_name'] . "\t" . $row['name'] . "\t" . $row['status'] . "\n";
}
?>