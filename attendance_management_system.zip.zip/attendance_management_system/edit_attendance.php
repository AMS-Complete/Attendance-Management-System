<?php
session_start();
include 'db.php';

if(!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }

$id = $_GET['id'];

// Purana record fetch karna
$res = mysqli_query($conn, "SELECT a.*, s.name FROM attendance a JOIN students s ON a.student_id = s.student_id WHERE a.attn_id = '$id'");
$row = mysqli_fetch_assoc($res);

if(isset($_POST['update'])) {
    $new_status = $_POST['status'];
    mysqli_query($conn, "UPDATE attendance SET status='$new_status' WHERE attn_id='$id'");
    echo "<script>alert('Attendance Updated Successfully!'); window.location.href='view_attendance.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Edit Attendance</title>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0 rounded-4 p-4">
                <h4 class="text-center mb-4 text-primary">Edit Attendance</h4>
                
                <div class="mb-3">
                    <label class="text-muted">Student Name</label>
                    <input type="text" class="form-control bg-white" value="<?php echo $row['name']; ?>" disabled>
                </div>

                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label">Update Status</label>
                        <select name="status" class="form-select form-select-lg">
                            <option value="Present" <?php if($row['status']=='Present') echo 'selected'; ?>>Present</option>
                            <option value="Absent" <?php if($row['status']=='Absent') echo 'selected'; ?>>Absent</option>
                        </select>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" name="update" class="btn btn-primary btn-lg rounded-pill">Save Changes</button>
                        <a href="view_attendance.php" class="btn btn-outline-secondary rounded-pill">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>