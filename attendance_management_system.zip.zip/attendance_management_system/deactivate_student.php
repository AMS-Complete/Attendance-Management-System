<?php
include 'db.php';
$id = $_GET['id'];

// Status column update karein (pehle table mein column add karna mat bhoolna)
mysqli_query($conn, "UPDATE students SET status = '0' WHERE student_id = '$id'");

header("Location: view_students.php?msg=deactivated");
?>