<?php
include 'db.php';

// 1. Agar 'id' URL se aa rahi hai, toh data fetch karo
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $res = mysqli_query($conn, "SELECT * FROM students WHERE student_id = '$id'");
    $student = mysqli_fetch_assoc($res);
}

// 2. Agar "Update" button dabaya jaye
if(isset($_POST['update'])) {
    $id = $_POST['student_id'];
    $name = $_POST['name'];
    $roll = $_POST['roll_no'];

    mysqli_query($conn, "UPDATE students SET name='$name', roll_no='$roll' WHERE student_id='$id'");
    
    // Update hone ke baad wapas list par bhej do
    header("Location: view_students.php?msg=updated");
}
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Edit Student</title>
</head>
<body class="container mt-5">
    <h3>Edit Student</h3>
    <form method="POST" class="mt-4">
        <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
        
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo $student['name']; ?>" required>
        </div>
        
        <div class="mb-3">
            <label>Roll No</label>
            <input type="text" name="roll_no" class="form-control" value="<?php echo $student['roll_no']; ?>" required>
        </div>
        
        <button type="submit" name="update" class="btn btn-primary">Update Student</button>
        <a href="view_students.php" class="btn btn-secondary">Cancel</a>
    </form>
</body>
</html>