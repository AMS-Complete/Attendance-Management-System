<?php
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Manage Students</title>
</head>
<body class="container mt-5">
    <div class="d-flex justify-content-between mb-4">
        <h3>Student Management</h3>
        <div>
            <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
            <a href="add_student.php" class="btn btn-success">+ Add New Student</a>
        </div>
    </div>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Roll No</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Sirf active students (status = 1) show honge
        $res = mysqli_query($conn, "SELECT * FROM students WHERE status = '1'");
        while($row = mysqli_fetch_assoc($res)) {
            echo "<tr>
                    <td>{$row['student_id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['roll_no']}</td>
                    <td>
                        <a href='edit_student.php?id={$row['student_id']}' class='btn btn-sm btn-primary'>Edit</a>
                        
                        <a href='deactivate_student.php?id={$row['student_id']}' class='btn btn-sm btn-warning'>Deact</a>
                        
                        <a href='delete_student.php?id={$row['student_id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"WARNING: Ye student aur uski SARI attendance delete kar dega. Confirm?\")'>Delete</a>
                    </td>
                  </tr>";
        }
        ?>
        </tbody>
    </table>
</body>
</html>