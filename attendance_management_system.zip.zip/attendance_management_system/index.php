<?php
session_start();
// Security Gate: Sirf logged-in users access kar sakte hain
if(!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include 'db.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .dashboard-card { transition: 0.3s; border-radius: 15px; }
        .dashboard-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-5 shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Attendance System</a>
        <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
    </div>
</nav>

<div class="container">
    <div class="mb-4">
        <h2 class="fw-bold">Welcome, <?php echo $_SESSION['admin']; ?>!</h2>
        <p class="text-muted">Manage your daily attendance activities from the dashboard below.</p>
    </div>

    <div class="row g-4">
        <?php if($_SESSION['role'] == 'admin') { ?>
        <div class="col-md-4">
            <div class="card dashboard-card p-4 text-center shadow-sm">
                <h5 class="mb-3">Students</h5>
                <div class="d-grid gap-2">
                    <a href="view_students.php" class="btn btn-primary">View All Students</a>
                    <a href="add_student.php" class="btn btn-outline-primary">Add New Student</a>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card dashboard-card p-4 text-center shadow-sm">
                <h5 class="mb-3">Attendance</h5>
                <div class="d-grid gap-2">
                    <a href="mark_attendance.php" class="btn btn-success">Mark Today's Attendance</a>
                </div>
            </div>
        </div>
        <?php } ?>

        <div class="col-md-4">
            <div class="card dashboard-card p-4 text-center shadow-sm">
                <h5 class="mb-3">Reports</h5>
                <div class="d-grid gap-2">
                    <a href="view_attendance.php" class="btn btn-warning text-white">View Attendance Records</a>
                    <a href="student_detail.php" class="btn btn-info text-white">Student-wise Report</a>
                    <a href="course_report.php" class="btn btn-secondary">Course-wise Report</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>